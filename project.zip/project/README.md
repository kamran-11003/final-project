# My TODO List
#### Video Demo: [YouTube Link](https://www.youtube.com/watch?v=7kCkjpFyThM)

## Description
The My TODO List is a web application that allows users to create and manage their tasks effectively. Users can add tasks, mark them as complete, and delete them as needed. The application is built using HTML, CSS, and JavaScript, providing a user-friendly interface and persistent storage using the browser's local storage.

## Features

- **Add tasks**: Users can enter task descriptions in the input field and click the "Add" button to add tasks to the list.
- **Display tasks**: The list displays all the tasks added by the user, providing a clear overview of pending and completed tasks.
- **Mark tasks as complete**: Users can mark tasks as complete by checking the checkbox next to each task. Completed tasks are visually distinguished from incomplete tasks, helping users track their progress.
- **Delete tasks**: Each task in the list has a "Delete" button that allows users to remove tasks from the list. This feature enables users to declutter their task list.
- **Clear all tasks**: The "Clear All" button provides a convenient way for users to remove all tasks from the list at once. This feature comes in handy when starting fresh or when all tasks are completed.
- **Persistence**: The application utilizes the browser's local storage to persist the tasks. This means that the tasks added by the user will be saved and available even if the page is refreshed or closed.

## Getting Started

To use the My TODO List application locally, follow these steps:

1. Clone the repository:

git clone https://github.com/your-username/todo-list.git

markdown
Copy code

2. Open the project directory:

cd todo-list

markdown
Copy code

3. Open the `index.html` file in a web browser.

4. Start managing your tasks!

## Usage

- Enter the task description in the input field and press Enter or click the "Add" button. The task will be added to the list.
- To mark a task as complete, click the checkbox next to the task description. The task will be visually marked as complete.
- To delete a task, click the "Delete" button next to the task. The task will be removed from the list.
- To clear all tasks, click the "Clear All" button. All tasks will be removed from the list.

## Technologies Used

- HTML: Used for structuring the web page.
- CSS: Used for styling the elements and layout of the TODO list.
- JavaScript: Used for handling user interactions, managing tasks, and updating the list.
- Local Storage: Used for persisting the tasks in the browser.

## Screenshots

![Screenshot 1](screenshots/screenshot1.png)
![Screenshot 2](screenshots/screenshot2.png)

## Future Enhancements

The My TODO List web application can be further improved with the following features:

- **Task Prioritization**: Implement a priority system for tasks to help users prioritize their work.
- **Due Dates and Reminders**: Allow users to set due dates for tasks and receive reminders for upcoming deadlines.
- **Task Categories or Tags**: Enable users to categorize or tag tasks for better organization and filtering.
- **Task Sorting and Filtering**: Provide options to sort and filter tasks based on various criteria, such as priority, due date, or category.
- **User Accounts and Collaboration**: Add user authentication to allow multiple users to create and manage their own task lists. Implement collaboration features for sharing and working on tasks together.
- **Mobile Responsive Design**: Make the application responsive to support various screen sizes and devices, allowing users to manage tasks on the go.

## Contributing

Contributions to the My TODO List project are welcome! If you have any ideas, suggestions, or bug reports, please open an issue on the [GitHub repository](https://github.com/your-username/todo-list). Feel free to fork the repository and submit pull requests for any improvements you'd like to make.

## License

This project is licensed under the [MIT License](LICENSE).

## Acknowledgments

The My TODO List project was inspired by the need for a simple and efficient task management tool. It was developed as a learning exercise and can serve as a foundation for building more advanced web applications.

Special thanks to [John Doe](https://github.com/johndoe) and [Jane Smith](https://github.com/janesmith) for their contributions to the project.

For any questions, issues, or feedback, please don't hesitate to reach out or open an issue on the GitHub repository. Enjoy using the My TODO List and stay organized!