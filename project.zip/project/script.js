let tasks = [];
document.addEventListener("DOMContentLoaded", () => {
  const savedTasks = localStorage.getItem("savedTasks");
  if (savedTasks)
  {
    tasks = JSON.parse(savedTasks);
  } else {
    tasks = [];
  }
  update();
});
document.getElementById("task-submit-btn").addEventListener("click", add=()=> {
const Description = document.getElementById("task-input").value;
  if (Description === "")
  {
    return;
  }
  else
  {
    tasks.push({ description:Description});
    localStorage.setItem("savedTasks", JSON.stringify(tasks));
    update();
    document.getElementById("task-input").value = "";
  }
});
document.getElementById("task-clear-btn").addEventListener("click", clear = () => {
  localStorage.removeItem("savedTasks");
  tasks = [];
  update();
});
const update = () => {
  const listElement = document.getElementById("tasksList");
  listElement.innerHTML = "";
  tasks.forEach((task, index) => {
  const itemElement = document.createElement("li");
  itemElement.className = "task-item";
  const textElement = document.createElement("span");
  textElement.className = "task-text";
  textElement.innerText = (index + 1) + '. ' + task.description;
  const controlsElement = document.createElement("div");
  controlsElement.className = "task-controls";
  const buttonElement = document.createElement("button");
  buttonElement.innerText = "Delete";
  buttonElement.className = "task-btn task-btn-delete";
  buttonElement.addEventListener("click", DeleteTask = (index) =>
  {
    tasks.splice(index, 1);
    localStorage.setItem("savedTasks", JSON.stringify(tasks));
    update();
  });
  controlsElement.append(buttonElement);
  itemElement.append(textElement);
  itemElement.append(controlsElement);
  listElement.append(itemElement);
  });
};
